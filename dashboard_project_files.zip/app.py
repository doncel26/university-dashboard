import streamlit as st
import pandas as pd
import numpy as np
import plotly.express as px

st.set_page_config(page_title='University Admissions Dashboard', layout='wide')

TEAM_MEMBERS = ['Melanny Doncel', 'Tu compañero/a']

@st.cache_data
def load_data(path='university_student_data.csv'):
    df = pd.read_csv(path)
    return df

st.title('University Admissions & Retention Dashboard')
st.caption('Interactive dashboard for admissions, enrollment, retention and satisfaction')

try:
    df = load_data()
except Exception as e:
    st.error('Could not load dataset. Make sure university_student_data.csv is in the same folder as app.py or provide a valid path.')
    st.stop()

if 'year' in df.columns:
    df['year'] = df['year'].astype(int)

# Sidebar filters
st.sidebar.header('Filters')
years = sorted(df['year'].unique().tolist()) if 'year' in df.columns else []
selected_year = st.sidebar.selectbox('Year', options=['All'] + years, index=0)

depts = sorted(df['department'].dropna().unique().tolist()) if 'department' in df.columns else []
selected_depts = st.sidebar.multiselect('Department', options=depts, default=depts)

terms = sorted(df['term'].dropna().unique().tolist()) if 'term' in df.columns else []
selected_term = st.sidebar.selectbox('Term', options=['All'] + terms, index=0)

# Apply filters
df_f = df.copy()
if selected_year != 'All':
    df_f = df_f[df_f['year'] == int(selected_year)]
if selected_depts:
    df_f = df_f[df_f['department'].isin(selected_depts)]
if selected_term != 'All':
    df_f = df_f[df_f['term'] == selected_term]

# KPIs
col1, col2, col3, col4 = st.columns(4)
with col1:
    enrolled = int(df_f['enrolled'].sum()) if 'enrolled' in df_f.columns else 0
    st.metric('Enrolled', f'{enrolled}')
with col2:
    admitted = int(df_f['admitted'].sum()) if 'admitted' in df_f.columns else 0
    st.metric('Admitted', f'{admitted}')
with col3:
    retention_rate = (df_f['retained_next_year'].sum() / df_f['enrolled'].sum()) if ('retained_next_year' in df_f.columns and df_f['enrolled'].sum()>0) else None
    st.metric('Retention rate', f'{retention_rate:.2%}' if retention_rate is not None else 'N/A')
with col4:
    avg_sat = df_f['satisfaction_score'].mean() if 'satisfaction_score' in df_f.columns else None
    st.metric('Avg satisfaction', f'{avg_sat:.2f}' if avg_sat is not None else 'N/A')

st.markdown('---')

# Visualization 1: Retention rate trend
st.subheader('Retention rate over time')
if 'retained_next_year' in df.columns and 'enrolled' in df.columns and 'year' in df.columns:
    trend = df.groupby('year').agg(retained=('retained_next_year','sum'), enrolled=('enrolled','sum')).reset_index()
    trend['retention_rate'] = trend['retained'] / trend['enrolled']
    fig1 = px.line(trend, x='year', y='retention_rate', markers=True, title='Retention rate by year')
    st.plotly_chart(fig1, use_container_width=True)

# Visualization 2: Satisfaction by year
st.subheader('Student satisfaction by year')
if 'satisfaction_score' in df.columns and 'year' in df.columns:
    sat = df.groupby('year').agg(avg_satisfaction=('satisfaction_score','mean')).reset_index()
    fig2 = px.bar(sat, x='year', y='avg_satisfaction', title='Average satisfaction by year')
    st.plotly_chart(fig2, use_container_width=True)

# Visualization 3: Spring vs Fall comparison
st.subheader('Spring vs Fall comparison')
if 'term' in df.columns and 'enrolled' in df.columns:
    term_comp = df.groupby('term').agg(enrolled=('enrolled','sum')).reset_index()
    fig3 = px.pie(term_comp, names='term', values='enrolled', title='Enrollment share by term')
    st.plotly_chart(fig3, use_container_width=True)

# Department breakdown
st.subheader('Department breakdown')
if 'department' in df.columns and 'enrolled' in df.columns:
    dept_tbl = df.groupby('department').agg(enrolled=('enrolled','sum'), avg_satisfaction=('satisfaction_score','mean')).reset_index().sort_values('enrolled', ascending=False)
    st.dataframe(dept_tbl)

st.sidebar.markdown('---')
st.sidebar.write('Team: ' + ', '.join(TEAM_MEMBERS))

st.write('\n\n---\nDashboard built with Streamlit.')
